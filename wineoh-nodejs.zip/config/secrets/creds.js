"use strict"
const SALSEFORCE_CRED = {
    email: 'kimberly.valencia@wine-oh.io',
    password: 'W1n0w1n0'
}
const ZENDESK_CRED = {
    ssoToken : 'MrOYf2Unm8YU2pyn0GIaLQvqqopVkQeZtF5MGVIvkJlPGvP0'
}
module.exports = {
    salesforceCreds: SALSEFORCE_CRED,
    zendeskCreds: ZENDESK_CRED
}