module.exports = {
    firebaseConfig : {
        apiKey: 'AIzaSyBuP6vTw0EJrmnY0o9-yVF5PIXH2nTA4BE',
        authDomain: 'web-app-a4b10.firebaseapp.com',
        databaseURL: 'https://web-app-a4b10.firebaseio.com',
        projectId: 'web-app-a4b10',
        storageBucket: 'web-app-a4b10.appspot.com',
        messagingSenderId: '1018721793832'
    },
    salesForceConfig : {
        username: 'kimberly.valencia@wine-oh.io',
        password: 'W1n0w1n0'
    },
    segmentConfig: {
        writeKey: 'jEssvE9eWKHUiAcD8TtaifBzfy4vQRZz'
    }
}